import AdminPanel from "./admin-panel";

export default AdminPanel;
