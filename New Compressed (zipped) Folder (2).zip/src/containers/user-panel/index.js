import UserPanel from "./user-panel";

export default UserPanel;
