import AdminPrivateRoute from "./admin-private-route";

export default AdminPrivateRoute;
