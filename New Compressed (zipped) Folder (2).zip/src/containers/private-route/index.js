import PrivateRoute from "./private-route";

export default PrivateRoute;
