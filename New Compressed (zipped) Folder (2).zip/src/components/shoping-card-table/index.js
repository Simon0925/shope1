import ShopingCardTable from "./shoping-card-table";

export default ShopingCardTable;
