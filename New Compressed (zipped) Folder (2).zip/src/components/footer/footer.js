import React from "react";
import "./footer.css";

import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <div className="footer">
      <div className="footer-box">
        <span className="here-footer">here will footer</span>
        <ul>
          <li>
            <Link to="/by"> by Semen Yakovenko </Link>
          </li>
          <li>
            <Link to="/admin">admin</Link>
          </li>
        </ul>
      </div>
    </div>
  );
};
export default Footer;
