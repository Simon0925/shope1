import React from "react";
import "./spiner.css";

const Spiner = () => {
  return <div>Loading...</div>;
};

export default Spiner;
