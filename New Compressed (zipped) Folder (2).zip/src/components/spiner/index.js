import Spiner from "./spiner";

export default Spiner;
