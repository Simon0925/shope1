import React from "react";
import "./error-indicator.css";

const ErrorIndicator = () => {
  return <div>Error!</div>;
};

export default ErrorIndicator;
