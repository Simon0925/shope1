import RightMenu from "./rightMenu";

export default RightMenu;
