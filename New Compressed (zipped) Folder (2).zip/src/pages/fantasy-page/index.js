import FantasyPage from "./fantasy-page";

export default FantasyPage;
