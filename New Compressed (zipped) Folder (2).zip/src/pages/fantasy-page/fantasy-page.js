import React from "react";

import "./fantasy-page.css";

const FantasyPage = () => {
  return (
    <div>
      <h1>Fantasy Page</h1>
    </div>
  );
};

export default FantasyPage;
