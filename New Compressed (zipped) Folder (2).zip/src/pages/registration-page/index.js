import RegistrationPage from "./registration-page";

export default RegistrationPage;
