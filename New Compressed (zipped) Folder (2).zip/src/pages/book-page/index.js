import BookPage from "./book-page";

export default BookPage;
