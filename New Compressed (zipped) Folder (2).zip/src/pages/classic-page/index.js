import ClassicPage from "./classic-page";

export default ClassicPage;
