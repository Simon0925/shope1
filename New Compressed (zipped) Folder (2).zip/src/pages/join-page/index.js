import Join from "./join.js";

export default Join;
