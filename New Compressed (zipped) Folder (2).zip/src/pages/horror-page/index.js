import HorrorPage from "./horror-page";

export default HorrorPage;
