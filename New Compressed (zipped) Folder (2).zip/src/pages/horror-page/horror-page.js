import React from "react";

import "./horror-page.css";

const HorrorPage = () => {
  return (
    <div>
      <h1>Fifth Product </h1>
      <h1>Fifth Product </h1>
      <h1>Fifth Product </h1>
    </div>
  );
};

export default HorrorPage;
