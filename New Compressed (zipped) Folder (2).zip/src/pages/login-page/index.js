import LoginPage from "./login-page";

export default LoginPage;
