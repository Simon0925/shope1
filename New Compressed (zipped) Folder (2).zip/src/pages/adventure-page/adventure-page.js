import React from "react";

import "./adventure-page.css";

const AdventurePage = () => {
  return (
    <div>
      <h1>Adventure Page</h1>
    </div>
  );
};

export default AdventurePage;
