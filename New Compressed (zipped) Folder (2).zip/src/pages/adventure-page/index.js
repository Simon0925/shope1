import AdventurePage from "./adventure-page";

export default AdventurePage;
