import UserAccountPage from "./user-account-page";

export default UserAccountPage;
