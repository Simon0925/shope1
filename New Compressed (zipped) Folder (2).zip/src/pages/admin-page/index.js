import AdminPage from "./admin-page";

export default AdminPage;
