import HomePage from "./home-page";

export default HomePage;
