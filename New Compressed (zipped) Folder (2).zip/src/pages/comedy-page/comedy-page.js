import React from "react";

import "./comedy-page.css";

const ComedyPage = () => {
  return (
    <div>
      <h1>Comedy Page</h1>
    </div>
  );
};

export default ComedyPage;
