import ComedyPage from "./comedy-page";

export default ComedyPage;
