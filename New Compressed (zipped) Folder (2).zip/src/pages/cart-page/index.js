import CartPage from "./cart-page";

export default CartPage;
