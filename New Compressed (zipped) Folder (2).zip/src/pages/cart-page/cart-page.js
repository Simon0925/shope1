import React from "react";

import "./cart-page.css";

const CartPage = () => {
  return <div>Cart Page</div>;
};

export default CartPage;
